# Kado
-Flower code from: https://codepen.io/mdusmanansari/pen/BamepLe


# Description
Flower code tiktok trend 

Responsive Web -- bisa langsung disesuikan di file css --> style.css

# Author
- Flower Code : Md Usman Ansari (@MdUsmanAnsari)
- Index Code : Septian Dwi Cahyo (@Septiandwica)

Thanks to codepan and mdusmanansari
